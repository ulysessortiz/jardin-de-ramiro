# Ramiro's Garden & Landscape Care

Final bilingual public website for Ramiro Monterroso.

## GitHub → Netlify workflow

1. Unzip this package.
2. Upload the **contents** to the root of the GitHub repository.
3. Commit the files.
4. In Netlify, choose **Add new project → Import an existing project → GitHub**.
5. Select the repository.
6. Build command: leave blank.
7. Publish directory: `.`
8. Deploy.

`netlify.toml` is already included, so Netlify should detect the publish directory automatically.

## Before handing out the QR

The included QR points to the stable current URL:
`https://jardinderamiro.netlify.app/`

That URL can remain usable even after a custom domain is attached in Netlify.

## Netlify Forms

The estimate form is named `ramiro-quote-request`. After the first Git-connected deploy, submit one test request and confirm it appears under **Netlify → Forms**. Configure notification email(s) in Netlify if desired.

## Private steward page

`/steward.html` is preserved and marked noindex. It is not linked from the public website. Its backend status has not been changed by this public-site rebuild.
