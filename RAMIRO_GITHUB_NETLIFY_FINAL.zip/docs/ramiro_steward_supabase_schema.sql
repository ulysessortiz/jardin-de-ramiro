-- Ramiro Business Steward Supabase Schema
create table if not exists quote_requests (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  email text,
  city_or_area text,
  service text,
  preferred_contact text,
  message text,
  status text default 'new',
  created_at timestamptz default now()
);
create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  address text,
  city text,
  service_type text,
  status text default 'active',
  notes text,
  next_step text,
  created_at timestamptz default now()
);
create table if not exists follow_up_reminders (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references clients(id) on delete set null,
  client_name text,
  action text not null,
  due_date date,
  status text default 'open',
  created_at timestamptz default now()
);
create table if not exists project_photos (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references clients(id) on delete set null,
  category text,
  notes text,
  storage_path text,
  approved_for_website boolean default false,
  created_at timestamptz default now()
);
create table if not exists website_update_requests (
  id uuid primary key default gen_random_uuid(),
  type text,
  details text not null,
  status text default 'needs_review',
  created_at timestamptz default now()
);
alter table quote_requests enable row level security;
alter table clients enable row level security;
alter table follow_up_reminders enable row level security;
alter table project_photos enable row level security;
alter table website_update_requests enable row level security;
create policy "authenticated manage quote requests" on quote_requests for all to authenticated using (true) with check (true);
create policy "authenticated manage clients" on clients for all to authenticated using (true) with check (true);
create policy "authenticated manage reminders" on follow_up_reminders for all to authenticated using (true) with check (true);
create policy "authenticated manage photos" on project_photos for all to authenticated using (true) with check (true);
create policy "authenticated manage updates" on website_update_requests for all to authenticated using (true) with check (true);
