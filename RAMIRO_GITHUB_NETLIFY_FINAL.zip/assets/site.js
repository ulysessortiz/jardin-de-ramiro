(() => {
  const supported = ['en','es'];
  const saved = localStorage.getItem('ramiro-language');
  const browser = (navigator.language || 'en').toLowerCase().startsWith('es') ? 'es' : 'en';
  let lang = supported.includes(saved) ? saved : browser;
  const buttons = document.querySelectorAll('[data-set-lang]');
  const formLang = document.querySelector('input[name="language"]');
  const alts = document.querySelectorAll('[data-alt-en][data-alt-es]');
  const setLanguage = (next) => {
    lang = supported.includes(next) ? next : 'en';
    document.body.classList.remove('lang-en','lang-es');
    document.body.classList.add(`lang-${lang}`);
    document.documentElement.lang = lang;
    localStorage.setItem('ramiro-language', lang);
    buttons.forEach(btn => btn.setAttribute('aria-pressed', String(btn.dataset.setLang === lang)));
    if (formLang) formLang.value = lang;
    alts.forEach(img => img.alt = img.dataset[`alt${lang[0].toUpperCase()+lang.slice(1)}`] || '');
    document.title = lang === 'es' ? 'Jardines y Paisajes de Ramiro | Orange County' : "Ramiro's Garden & Landscape Care | Orange County";
  };
  buttons.forEach(btn => btn.addEventListener('click', () => setLanguage(btn.dataset.setLang)));
  setLanguage(lang);
  const year = document.querySelector('[data-year]');
  if (year) year.textContent = new Date().getFullYear();
})();
